cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "id": "es6-promise-plugin.Promise",
        "file": "plugins/es6-promise-plugin/www/promise.js",
        "pluginId": "es6-promise-plugin",
        "runs": true
    },
    {
        "id": "aerogear-cordova-push.AeroGear.ajax",
        "file": "plugins/aerogear-cordova-push/www/aerogear.ajax.js",
        "pluginId": "aerogear-cordova-push",
        "clobbers": [
            "ajax"
        ]
    },
    {
        "id": "aerogear-cordova-push.AeroGear.UnifiedPush",
        "file": "plugins/aerogear-cordova-push/www/aerogear-push.js",
        "pluginId": "aerogear-cordova-push",
        "clobbers": [
            "push"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-whitelist": "1.3.4-dev",
    "es6-promise-plugin": "4.2.2",
    "aerogear-cordova-push": "3.1.0"
};
// BOTTOM OF METADATA
});