//this file gets browserified any updates to it will not be reflected in the studio preview

var angular = require("angular");
require("angular-animate");
require("angular-ui-router");
require("ionic-scripts");
require("angular-sanitize");

angular.module('app', ['ionic', 'app.controllers', 'app.routes', 'app.services'])
.constant('$fh', require("fh-js-sdk"))
.constant('moment', require("moment"))

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if(window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
    }
    if(window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }
  });

  try {
        var onPush = function (e) {
            alert(e.alert)
        }

        var onRegisterSuccess = function () {
            console.log('registered for push')
        }

        var onRegisterFail = function (e) {
            console.log('failed to register for push')
            console.log(e)
        }

        $fh.push(onPush, onRegisterSuccess, onRegisterFail, {
            alias: 'eshortis@redhat.com',
            categories: ['hurling']
        })
    } catch (e) {
        alert(e.toString())
    }
});
